-- ==========================
-- fichier      : afficher_base_gestloc.sql
-- base         : gestloc
-- auteur(s)    : SIMON Kevin
-- date         : 19/11/22
-- role         : afficher le contenu des tables de la bd gestloc
-- projet       : gestloc
-- ==========================

SELECT * FROM AGENCE;

SELECT * FROM PROPRIETAIRE;

SELECT * FROM LOCATAIRE;

SELECT * FROM SYNDIC;

SELECT * FROM BIEN;

SELECT * FROM LOCATION;

SELECT * FROM VISITE;

SELECT * FROM DPE;